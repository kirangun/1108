package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Customer;
import com.cg.bean.Room;
import com.cg.dao.HotelDaoImpl;
import com.cg.dao.IHotelDao;

@Service
public class HotelServiceImpl implements IHotelService {

	@Autowired
	IHotelDao dao;
	Customer customer;

	public HotelServiceImpl() {
		super();
		dao = new HotelDaoImpl();
	}

	@Override
	public Customer createProfile(Customer cust) {
		Customer cus = dao.createProfile(cust);
		return cus;

	}

	@Override
	public Customer validateCustomer(Customer cust) {

		return dao.validateCustomer(cust);
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	@Override
	public Room bookInRoom(Room room) {
		return dao.bookInRoom(room);
	}

	@Override
	public List<Room> getRommDetails(Room room) {
		return dao.getRommDetails(room);
	}

}
