var bar1 = new ldBar("#myItem1");
var bar2 = document.getElementById('myItem1').ldBar;
bar1.set(35);