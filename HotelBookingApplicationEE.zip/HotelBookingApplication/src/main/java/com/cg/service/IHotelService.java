package com.cg.service;

import java.util.List;

import com.cg.bean.Customer;
import com.cg.bean.Room;

public interface IHotelService {

	public Customer createProfile(Customer cust);

	public Customer validateCustomer(Customer cust);

	public Room bookInRoom(Room room);

	public List<Room> getRommDetails(Room room);

}
