/*global console, alert, prompt*/
// Function semantic 
/*jslint browser: true, devel: true, plusplus: true */


(function bgChange() {
    "use strict";
    var bgclr  = document.getElementById("bgclr"),
        math     = Math.random() * 2,
        ceil     = Math.ceil(math);
    
    if ((ceil) === 1) {
        bgclr.style.backgroundColor = "#0f4b62";
		

    } 

	else {
        bgclr.style.backgroundColor = "#f2ceec";
    }
    
    window.setTimeout(bgChange, 250);
}());


(function eyeChange() {
    "use strict";
    var leftEye  = document.getElementById("left-eye"),
        rightEye = document.getElementById("right-eye"),
        math     = Math.random() * 2,
        ceil     = Math.ceil(math);
    
    if ((ceil) === 1) {
        leftEye.style.backgroundColor = "#961f1f";
        rightEye.style.backgroundColor = "#93E400";
    } else {
        rightEye.style.backgroundColor = "#961f1f";
        leftEye.style.backgroundColor = "#93E400";
    }
    
    window.setTimeout(eyeChange, 250);
}());


(function mouthChange() {
    "use strict";
    var mouth    = document.getElementById("mouth"),
        lower    = document.getElementById("lower"),
        teeth    = document.getElementById("teeth"),
        back     = document.getElementById("back-teeth"),
        math     = Math.random() * 2,
        ceil     = Math.ceil(math);
    
    if ((ceil) === 1) {
        mouth.style.height   = "35px";
        mouth.style.transition = "all 0.5s ease-in-out";
        back.style.height = "25px";
        back.style.transition = "all 0.5s ease-in-out";
        lower.style.marginTop = "10px";
        lower.style.transition = "all 0.5s ease-in-out";
    } else {
        mouth.style.height = "25px";
        back.style.height = "15px";
        lower.style.marginTop = "0px";
    }
    
    window.setTimeout(mouthChange, 500);
}());

var clk = 1;
(function pulse() {
    "use strict";
    
    // some variables //
    var firstPin      = document.getElementById("first-pin"),
        secondPin     = document.getElementById("second-pin"),
        thirdPin      = document.getElementById("third-pin"),
        forthPin      = document.getElementById("forth-pin");
    // some variables //
    
    // clock pulse //
    clk += 1;
    window.setTimeout(pulse, 300);
    if (clk > 4) {
        clk = 1;
    }
    // clock pulse //
    
    // conditions //
    if (clk === 1) {
        firstPin.style.backgroundColor = "red";
        secondPin.style.backgroundColor = "blue";
        thirdPin.style.backgroundColor = "blue";
        forthPin.style.backgroundColor = "blue";
    } else if (clk === 2) {
        firstPin.style.backgroundColor = "blue";
        secondPin.style.backgroundColor = "red";
        thirdPin.style.backgroundColor = "blue";
        forthPin.style.backgroundColor = "blue";
    } else if (clk === 3) {
        firstPin.style.backgroundColor = "blue";
        secondPin.style.backgroundColor = "blue";
        thirdPin.style.backgroundColor = "red";
        forthPin.style.backgroundColor = "blue";
    } else {
        firstPin.style.backgroundColor = "blue";
        secondPin.style.backgroundColor = "blue";
        thirdPin.style.backgroundColor = "blue";
        forthPin.style.backgroundColor = "red";
    }
}());



/**New Js for Text*/

var TxtType = function(el, toRotate, period) {
        this.toRotate = toRotate;
        this.el = el;
        this.loopNum = 0;
        this.period = parseInt(period, 10) || 2000;
        this.txt = '';
        this.tick();
        this.isDeleting = false;
    };

    TxtType.prototype.tick = function() {
        var i = this.loopNum % this.toRotate.length;
        var fullTxt = this.toRotate[i];

        if (this.isDeleting) {
        this.txt = fullTxt.substring(0, this.txt.length - 1);
        } else {
        this.txt = fullTxt.substring(0, this.txt.length + 1);
        }

        this.el.innerHTML = '<span class="wrap">'+this.txt+'</span>';

        var that = this;
        var delta = 200 - Math.random() * 100;

        if (this.isDeleting) { delta /= 2; }

        if (!this.isDeleting && this.txt === fullTxt) {
        delta = this.period;
        this.isDeleting = true;
        } else if (this.isDeleting && this.txt === '') {
        this.isDeleting = false;
        this.loopNum++;
        delta = 500;
        }

        setTimeout(function() {
        that.tick();
        }, delta);
    };

    window.onload = function() {
        var elements = document.getElementsByClassName('typewrite');
        for (var i=0; i<elements.length; i++) {
            var toRotate = elements[i].getAttribute('data-type');
            var period = elements[i].getAttribute('data-period');
            if (toRotate) {
              new TxtType(elements[i], JSON.parse(toRotate), period);
            }
        }
        // INJECT CSS
        var css = document.createElement("style");
        css.type = "text/css";
        css.innerHTML = ".typewrite > .wrap { border-right: 0.08em solid #fff}";
        document.body.appendChild(css);
		
		
		    /*setInterval(function(){ 
			window.location = '../SIP/display.html';  
		}, 3000);*/
    };
	
	
	
	